﻿float a = 0.1f + 0.2f;
Console.WriteLine(a);

if (a == 0.3f)
{
    Console.WriteLine("Равны");
}
else
{
    Console.WriteLine("Не Равны");
}
