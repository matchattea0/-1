﻿using System.Security.Cryptography;

/* first */

Console.WriteLine("Calculator");
Console.WriteLine("----------------");

long a;
long b;
byte c;
Console.WriteLine("Input a: ");
a = Convert.ToInt64(Console.ReadLine());
Console.WriteLine("Input b: ");
b = Convert.ToInt64(Console.ReadLine());
Console.WriteLine("Input c: ");
c = Convert.ToByte(Console.ReadLine());
Console.WriteLine("a - b - c = " + (a - b - c));
Console.WriteLine("a + b + c = " + (a + b + c));
Console.WriteLine("a - (b - c) = " + (a * b));

Console.WriteLine("----------------");

/* second  */
double a1;
double b1;
Console.WriteLine("Input a1: ");
a1 = Convert.ToDouble(Console.ReadLine());
Console.WriteLine("Input b1: ");
b1 = Convert.ToDouble(Console.ReadLine());
Console.WriteLine("a * b * c = " + (a1 * b1));
Console.WriteLine("a / (b - a) = " + (a1 / (b1 - a1)).ToString("F4"));

